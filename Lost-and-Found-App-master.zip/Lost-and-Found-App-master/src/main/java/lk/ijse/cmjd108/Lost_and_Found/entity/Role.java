package lk.ijse.cmjd108.Lost_and_Found.entity;

public enum Role {
    ADMIN, STAFF, USER
}
