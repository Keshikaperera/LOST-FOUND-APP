package lk.ijse.cmjd108.Lost_and_Found.dto;

import lombok.Data;

@Data
public class SigninRequest {
    private String username;
    private String password;
}