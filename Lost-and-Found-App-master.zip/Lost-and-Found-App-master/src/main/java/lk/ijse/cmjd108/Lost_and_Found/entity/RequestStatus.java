package lk.ijse.cmjd108.Lost_and_Found.entity;

public enum RequestStatus {
    PENDING, APPROVED, REJECTED
}
