package lk.ijse.cmjd108.Lost_and_Found;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LostAndFoundApplicationTests {

	@Test
	void contextLoads() {
	}

}
